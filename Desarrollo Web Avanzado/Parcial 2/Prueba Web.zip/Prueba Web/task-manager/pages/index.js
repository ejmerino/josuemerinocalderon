const Home = () => {
  return (
    <div>
      <h1>Welcome to Task Manager</h1>
      <a href="/register">Register</a>
      <br />
      <a href="/login">Login</a>
    </div>
  );
};

export default Home;
