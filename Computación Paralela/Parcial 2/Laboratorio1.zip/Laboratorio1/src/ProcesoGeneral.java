import javax.swing.*;
import java.util.concurrent.Semaphore;

public class ProcesoGeneral extends JFrame {
    private JProgressBar progresoGeneral;
    private JProgressBar[] barrasSubprocesos;
    private Subproceso[] subprocesos;
    private Semaphore semaforo;
    
    public ProcesoGeneral() {
        setTitle("Simulación de Proceso de Tarjeta de Crédito");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new java.awt.GridLayout(6, 1));
        
        semaforo = new Semaphore(1);
        progresoGeneral = new JProgressBar(0, 100);
        add(new JLabel("Progreso General:"));
        add(progresoGeneral);
        
        String[] nombres = {"Información Personal", "Ingresos", "Egresos", "Referencias", "Formas de Pago"};
        int[] tiempos = {1, 2, 2, 1, 2}; // en horas
        int[] aportes = {40, 10, 10, 5, 35}; // en porcentaje
        
        barrasSubprocesos = new JProgressBar[5];
        subprocesos = new Subproceso[5];
        
        for (int i = 0; i < 5; i++) {
            barrasSubprocesos[i] = new JProgressBar(0, 100);
            subprocesos[i] = new Subproceso(nombres[i], tiempos[i], aportes[i], semaforo, barrasSubprocesos[i]);
            add(new JLabel(nombres[i] + ":"));
            add(barrasSubprocesos[i]);
        }
        
        setVisible(true);
        
        for (Subproceso subproceso : subprocesos) {
            subproceso.start();
        }
        
        new Thread(() -> {
            try {
                while (true) {
                    int progresoTotal = 0;
                    for (Subproceso subproceso : subprocesos) {
                        progresoTotal += subproceso.getAporte() * subproceso.barraProgreso.getValue() / 100;
                    }
                    progresoGeneral.setValue(progresoTotal);
                    Thread.sleep(100);
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();
    }
    
    public static void main(String[] args) {
        new ProcesoGeneral();
    }
}
