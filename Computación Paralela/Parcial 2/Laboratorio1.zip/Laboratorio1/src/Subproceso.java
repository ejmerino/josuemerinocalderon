import java.util.concurrent.Semaphore;

public class Subproceso extends Thread {
    private String nombre;
    private int tiempo; // en segundos
    private int aporte; // en porcentaje
    private Semaphore semaforo;
    javax.swing.JProgressBar barraProgreso;
    
    public Subproceso(String nombre, int tiempo, int aporte, Semaphore semaforo, javax.swing.JProgressBar barraProgreso) {
        this.nombre = nombre;
        this.tiempo = tiempo;
        this.aporte = aporte;
        this.semaforo = semaforo;
        this.barraProgreso = barraProgreso;
    }
    
    @Override
    public void run() {
        try {
            semaforo.acquire();
            for (int i = 0; i <= 100; i++) {
                barraProgreso.setValue(i);
                Thread.sleep(tiempo * 50); // Simulando la duración del subproceso
            }
            semaforo.release();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    
    public int getAporte() {
        return aporte;
    }
}